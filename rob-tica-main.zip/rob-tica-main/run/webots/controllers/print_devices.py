"""
Some useful functions for Webots and for working with the epuck robot (https://cyberbotics.com/doc/guide/epuck?version=R2021a).
By: Gonçalo Leão
"""
from controllers.utils import print_devices

print_devices()
