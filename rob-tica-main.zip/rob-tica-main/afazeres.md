### Horário:
Todos: terça 14h-18h

### Afazeres:
- tratamento dados LIDAR para serem utilizados pelos algos (Matheus)
- criação de novos mapas/cenários (Miguel)
- parte teórica de compreensão e implementação dos algos (Anna)
